public class FightOutcome {
    public boolean ranAway = false;
    public Player player = null;
    public boolean monsterDefeated = false;
}
