public enum MonsterType {
    NORMAL("NORMAL"),
    BOSS("BOSS");


    private String value;

    MonsterType(String value){
        this.value = value;
    }

    public String getValue(){
        return value;
    }
}
