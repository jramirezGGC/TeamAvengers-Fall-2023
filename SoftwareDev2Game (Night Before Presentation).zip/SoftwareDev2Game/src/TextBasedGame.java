

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;


public class TextBasedGame{

    private Scanner scanner;

    public TextBasedGame() {
        scanner = new Scanner(System.in);
    }

    public Player generatePlayer(){
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to the game! This game is set in a dystopian future where you are fighting for survival.");//Gland added welcome message
        System.out.println("Please enter your name: ");
        String playerName = input.nextLine();
        System.out.println("Please enter a description for yourself: ");//Gland added player description
        String playerDescription = input.nextLine();                                        //inv               //equiped
        Player player = new Player(playerName,playerDescription,"B1/Pantry",new ArrayList<>(),new ArrayList<>(),100,new ArrayList<>());
        return player;
    }

    public void playGame(Map<String,Room> rooms) {
        Player player = generatePlayer();
        System.out.println("Hello " + player.getName());
        boolean running = true;
        while (running) {
            Room room = rooms.get(player.getCurrentRoomName());
            System.out.println("Your name is : " + player.getName()); // Player name tracked
            System.out.println(player.getName()+"'s description : " + player.getDescription());
            System.out.println("HP: " + player.getHP()); // player HP
            System.out.println("Item selected : " + Item.getSelectedAsString(player.getSelected()));
            System.out.println("Items in your inventory : " + Item.getInvAsString(player.getInventory())); // logging items in inventory
            System.out.println("Items equipped : " + Item.getEquippedAsString(player.getEquipped())); // logging items equipped
            System.out.println("You are in " + room.getName()); // logging current location
            System.out.println(room.getName() +"Description: " + room.getDescription()); // logging room desc & name
//            System.out.println("Room Type: " + room.getRoomType());// logging room type
//            System.out.println("Available connections: " + room.getConnections().keySet());// logging avalible connections
//            System.out.println("Items in the room : " + Item.getInvAsString(room.getItems())); // logging items in room
//            System.out.println("Puzzles in the room : " + Puzzle.getPuzzleAsString(room.getPuzzles())); // logging puzzles in room
//            System.out.println("Puzzle desc : " + Puzzle.getPuzzleDesc(room.getPuzzles())); // logging puzzles in room
 //           System.out.println("Monsters in the room : " + Monster.getMonsterAsString(room.getMonsters())); // logging monsters in room
            System.out.println();
            for (String direction : room.getConnections().keySet()) {
                System.out.print(direction + " ");
            }

            System.out.println("Enter the direction you want to go (move : N, S, W, E), 'quit' to exit ");
            System.out.println("Use (help) for a list of all commands and applicable actions ");
            System.out.println();
            String input = scanner.nextLine();
            input = input.toLowerCase();
            String[] inputParts = input.split(" ");
            String command = inputParts[0];
            System.out.println();
            List<Item> playerInventory = player.getInventory();
            boolean hasFlashLight = player.getInventory().stream().anyMatch(item -> item.getName().toLowerCase().equalsIgnoreCase("Flashlight"));
            if ("E1/Survivor Camp".equalsIgnoreCase(room.getName())){
                System.out.println("Congratulations! You made it to the survivor camp!");
                System.out.println("Do you want to start over or end the game? (start/end)");
                String decision = scanner.nextLine().toLowerCase();

                switch (decision) {
                    case "start":

                        System.out.println("New game started!");
                        TextBasedGame game = new TextBasedGame();
                        Map<String,Monster> monsters = MonsterReader.readMonstersFromFile("monsters.txt");
                        Map<String,Puzzle> puzzles = PuzzleReader.readPuzzlesFromFile("puzzles.txt");
                        Map<String,Item> items = ItemReader.readItemsFromFile("items.txt");

                        Map<String,Room> rooms1 = MapReader.loadMapFromFile("map.txt",items,puzzles,monsters);

                        game.playGame(rooms1);
                        break;
                    case "end":
                        System.out.println("Thanks for playing! Goodbye.");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter 'start' or 'end'.");
                        break;
                }
            }
            switch (command){
                case "exit":
                    running = false;
                    System.out.println("Coward");
                    break;
                case "use":
                    String[] parts = input.split(" ");
                    if(parts.length >= 2 && parts[1].equals("healingstation")) {
                        if (room.getRoomType() == RoomType.HEALROOM) {
                            System.out.println("You are in " + room.getName() + ". You see that there is a healing fountain here");
                            System.out.println("Do you want to use this healing fountain? (Yes/No)");
                            String decision = scanner.nextLine().toLowerCase();

                            if (decision.equals("yes")) {
                                player.setHP(player.getMaxHP());
                                System.out.println("You have healed to full health!");
                            } else if (decision.equals("no")) {
                                System.out.println("You didn't heal from the fountain.");
                            } else {
                                System.out.println("Invalid choice. Please enter 'yes' or 'no'.");
                            }
                        } else {
                            System.out.println("You can only use the healingstation command in a HEALROOM.");
                        }
                    }
                    break;
                case "jump":
                    if(!room.getName().equals("B3/Greenhouse")){
                        System.out.println("You jumped in the air");
                    }
                    if (room.getName().equals("B3/Greenhouse")) {
                        Puzzle seeAndDoPuzzle = room.checkIfPuzzleInRoom("SeeAndDo");
                        if (seeAndDoPuzzle != null) {
                            System.out.println(seeAndDoPuzzle.getDesc());
                            String playerResponse = scanner.nextLine().toLowerCase();
                            if (playerResponse.equals(seeAndDoPuzzle.getAns())) {
                                System.out.println("You jumped for joy then sprinted away! You can now move forward.");
                            }
                            else if(playerResponse.equals("hint")){
                                System.out.println(seeAndDoPuzzle.getHint());
                            }
                            else {
                                System.out.println("Incorrect response. Try again.");
                                player.getPrevRoomName();
                            }
                        }
                    }
                    break;
                case "move":
                    String[] movement = input.split(" ");
                    String roomName = room.getConnectedRoomName(movement[1]);
                    System.out.println(roomName);
                    if(roomName != null){
                        player.moveToRoom(roomName);
                    }else {
                        System.out.println("You can't go that way.");
                        System.out.println();
                    }
                    break;
                case "grab":
                    String[] argumentsPickup = input.split(" "); // Extract the item name
                    Item itemBeingPickedUp = room.pickUpItem(argumentsPickup[1]);
                    System.out.println("What do you want to do? (Keep, Discard, or type Exit to exit the inventory menu).");//Gland implemented keep, discard, and exit commands for grabbing items
                    if(itemBeingPickedUp != null){
                       // player.addItem(itemBeingPickedUp);
                        String input2 = scanner.nextLine();
                        input2 = input2.toLowerCase();
                        String[] input2Parts = input2.split(" ");
                        String command2 = input2Parts[0];
                        switch (command2){
                            case "exit":
                                room.addItemToRoom(itemBeingPickedUp);
                                System.out.println("You lef tthe item exited the inventory menu.");
                                break;
                            case "keep":
                                player.addItem(itemBeingPickedUp);
                                System.out.println("You kept the item.");
                                break;
                            case "discard":

                                room.addItemToRoom(itemBeingPickedUp);
                                System.out.println("You discarded the item.");
                                break;
                        }
                    }else{
                        System.out.println("Item is not in room");
                        System.out.println();
                    }
                    break;
                case "discard":
                    String[] argumentsDrop = input.split(" "); // Extract the item name
                    Item itemBeingDropped = player.dropItem(argumentsDrop[1]);
                    if (argumentsDrop[1].equalsIgnoreCase("helmet")) {//Gland implemented health decrease for discarding an equipped helmet
                        player.setHP(player.getHP()- 7);
                        System.out.println("Item has been discarded.");
                        room.addItemToRoom(itemBeingDropped);
                    }else if (argumentsDrop[1].equalsIgnoreCase("armorvest")) {//Gland implemented health decrease for discarding an equipped ArmorVest
                        player.setHP(player.getHP()- 15);
                        room.addItemToRoom(itemBeingDropped);
                    }else if (argumentsDrop[1].equalsIgnoreCase("shield")) {//Gland implemented health decrease for discarding an equipped shield
                        player.setHP(player.getHP()- 3);
                        System.out.println("Item has been discarded.");
                        room.addItemToRoom(itemBeingDropped);
                    }else if (itemBeingDropped != null) {
                        room.addItemToRoom(itemBeingDropped);
                        System.out.println("Item has been discarded.");
                    } else {
                        System.out.println("Item is not in inventory or hand");//Gland extended "discard" to also search in equipped list
                        System.out.println();
                    }
                    break;
                case "inspect":
                    String[] inspectItems = input.split(" ");
                    Item itemInRoom = room.checkIfItemInRoom(inspectItems[1]);
                    Item itemInInventory = player.checkIfItemInInventory(inspectItems[1]);
                    if(itemInRoom == null && itemInInventory == null){
                        System.out.println("This is not in your inventory or not in the room");
                        break;
                    }
                    if(itemInRoom != null){
                        System.out.println("Item Desc: " + itemInRoom);
                        break;
                    }
                    if(itemInInventory != null){
                        System.out.println("Item Desc " + itemInInventory);
                        break;
                    }
                    break;
                case "analyze":
                    String[] examineMonster = input.split(" ");
//                    Monster monsterBeingExamined = room.getMonsters().stream().filter(monster -> examineMonster[1]
//                            .equals(monster.getName().toLowerCase())).findAny().orElse(null);  CODE FOR MULTIPLES
                    Monster monsterBeingExamined = room.getMonsters().stream().findFirst().orElse(null);
                    if(room.getMonsters().contains(monsterBeingExamined)) {
                        System.out.println("Monster Desc: " + monsterBeingExamined.getDesc() + "MonsterHP : " + monsterBeingExamined.getHp() + "MonsterDMG : " + monsterBeingExamined.getAtk());
                    }
                    break;
                case "scan":
                        System.out.println("There is a, " + room.getMonsters());
                        System.out.println("Items: " + room.getItems());
                        System.out.println("Puzzles: " + room.getPuzzles());
                    break;
                case "say":
                    // need to get puzzles in room (make new method for puzzle)
                    if(room.getPuzzles() == null || room.getPuzzles().isEmpty()){
                        System.out.println("There is no puzzle in this room");
                        break;
                    }
                    final String userInput = input.trim().toLowerCase();
                    List<Puzzle> roomPuzzles = room.getPuzzles();
                    List<String> puzzleSolved = new ArrayList<>();
                    roomPuzzles.stream().forEach(puzzle -> {
                        String puzzleAns = puzzle.getAns().toLowerCase();
                        if(userInput.equals(puzzleAns)){
                            System.out.println("This puzzle has been solved!");
                            puzzleSolved.add(puzzle.getName());
                        }else{
                            System.out.println("You answered wrong :" + userInput);
                        }
                    });
                    puzzleSolved.stream().forEach(puzzle -> {
                        room.getPuzzles().removeIf(p -> p.getName().equals(puzzle));
                    });
                    break;
                case "hint":
                    String[] puzzleHint = input.split(" ");
                    Puzzle hintPuzzle = room.checkIfPuzzleInRoom(puzzleHint[1]);
                    if(hintPuzzle != null){
                        System.out.println("Hint : " + hintPuzzle.getHint());
                    }else{
                        System.out.println("There is no puzzle of that nature in this room");
                        break;
                    }
                    break;
                case "inventory":
                        System.out.println("Items in your backpack : " + Item.getInvAsString(player.getInventory()));
                    break;
                case "select":
                    // String[] selectName = input.split(" "); // extract equipment Name
                    System.out.println("Which item would you like to select?" );
                    Scanner inputSelect = new Scanner(System.in);
                    String selectName = inputSelect.nextLine(); ;
                    Item itemBeingSelected = player.checkIfItemInInventory(selectName.toLowerCase()); //[1]
                    if(player.getInventory().contains(itemBeingSelected)){
                        player.getInventory().remove(itemBeingSelected);
                        System.out.println("You have selected " + itemBeingSelected.getName());
                        player.addSelected(itemBeingSelected);
                    }
                    break;
                case "equip":
                    String[] equipmentName = input.split(" "); // extract equipment Name
                    Item itemBeingEquipped = player.checkIfItemInInventory(equipmentName[1].toLowerCase());
                    if (input.equalsIgnoreCase("equip helmet")) {//Gland added health for equipping helmet
                        Item helmetToEquip = player.checkIfItemInInventory("helmet");
                        if (player.getInventory().contains(helmetToEquip)) {
                            player.getInventory().remove(helmetToEquip);
                            player.setHP(player.getHP()+ 7);
                            System.out.println("You have equipped Helmet.");
                            player.addEquipment(helmetToEquip);
                        }

                    }else if (input.equalsIgnoreCase("equip armorvest")) {//Gland added health for equipping ArmorVest
                        Item armorVestToEquip = player.checkIfItemInInventory("armorvest");
                        if (player.getInventory().contains(armorVestToEquip)) {
                            player.getInventory().remove(armorVestToEquip);
                            player.setHP(player.getHP()+ 15);
                            System.out.println("You have equipped ArmorVest.");
                            player.addEquipment(armorVestToEquip);
                        }
                    }else if (input.equalsIgnoreCase("equip shield")) {//Gland added health for equipping shield
                        Item shieldToEquip = player.checkIfItemInInventory("shield");
                        if (player.getInventory().contains(shieldToEquip)) {
                            player.getInventory().remove(shieldToEquip);
                            player.setHP(player.getHP()+ 3);
                            System.out.println("You have equipped Shield.");
                            player.addEquipment(shieldToEquip);
                        }
                    }else if(player.getInventory().contains(itemBeingEquipped)){
                        player.getInventory().remove(itemBeingEquipped);
                        System.out.println("You have equipped " + itemBeingEquipped.getName());
                        player.addEquipment(itemBeingEquipped);
                    }
                    break;
                case "help":
                        System.out.println("commands available are : ");
                        System.out.println("Combat : fight(initiates combat), inspect, attack, run, ignore(removes monster) (TBA: Dodge, Skill, Shield)");
                        System.out.println("Item interaction : grab, discard, analyze, consume, all of these require the item's associated name, and inventory (TBA: select, keep");
                        System.out.println("Navigation : move (N,S,E,W) not case sensitive");
                        System.out.println("Puzzle interaction : say(only command for now), jump(not yet implemented), keep(not yet implemented)");
                        System.out.println("Misc : scan(for all the rooms properties), TBA(Save,Load,Start)");
                    System.out.println();
                    break;
                case "combat":
                        System.out.println("You are now fighting monster");
                        Monster monster = room.getMonsters().stream().findFirst().orElse(null);
                        if(monster == null){
                            System.out.println("There are no monsters in this room.");
                        }
                        FightOutcome fightOutcome = FightManager.fight(player,monster);
                        player = fightOutcome.player;
                        if(player.getHP() == 0){
                            System.out.println("You have lost you are a loser");
                            running = false;
                            break;
                        }
                        if(fightOutcome.ranAway){
                            player.moveToRoom(player.getPrevRoomName());
                        }
                        if(fightOutcome.monsterDefeated){
                            room.removeMonster(monster.getName());
                    }
                    break;
                case "ignore" :
                    String[] monsterName = input.split(" ");
                    if(monsterName.length != 2){
                        System.out.println("you must type the monsters name");
                        continue;
                    }
                    Monster monsterInRoom = room.checkIfMonsterInRoom(monsterName[1]);
                    if(monsterInRoom != null){
                        room.removeMonster(monsterInRoom.getName());
                    }
                    break;
                case "consume" :
                    String[] consumeName = input.split(" ");
                    if(consumeName.length != 2){
                        System.out.println("You must type the consumables name");
                        continue;
                    }
                    Item itemBeingConsumed = player.checkIfItemEquipped(consumeName[1].toLowerCase());
                    if(itemBeingConsumed != null){
                        int playerHP = player.setHP(player.getHP() + itemBeingConsumed.getEffect());
                        player.getEquipped().remove(itemBeingConsumed);
                        System.out.println("You have consumed : " + itemBeingConsumed);
                    }
                    break;
                case "save":
//                    MapReader.saveGameToFile(rooms,"saved_game.txt");
//                    System.out.println("Game has been saved");
                    saveGame(player,rooms);
//                    player.savePlayerSession("playerData.txt");
                    System.out.println("Saved game");
                    break;
                case "load":
//                    rooms = MapReader.loadGameFromFile("saved_game.txt");
//                    rooms = loadGame(); working version is this line
                    LoadedGameData loadedGameData = loadGame();
                    if (loadedGameData != null) {
                        player = loadedGameData.getLoadedPlayer();
                        rooms = loadedGameData.getLoadedRooms();
                    }
                    System.out.println("Game loaded successfully");
                    break;
                default:
                    System.out.println("Invalid command. Try again.");
                    System.out.println();
                    break;
            }
        }
    }
    public void saveGame(Player player, Map<String, Room> rooms) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("saved_game1.txt"))) {
            oos.writeObject(player);
            oos.writeObject(rooms);
            System.out.println("Game saved successfully!");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error saving game: " + e.getMessage());
        }
    }

//    public Map<String, Room> loadGame() {
//        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("saved_game1.txt"))) {
//            return (Map<String, Room>) ois.readObject();
//        } catch (IOException | ClassNotFoundException e) {
//            e.printStackTrace();
//            System.err.println("Error loading game: " + e.getMessage());
//        }
//        return null;
//    }

    private LoadedGameData loadGame() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("saved_game1.txt"))) {
            // Load player data
            Player loadedPlayer = (Player) ois.readObject();
            // Load rooms map
            Map<String, Room> loadedRooms = (Map<String, Room>) ois.readObject();
            System.out.println("Game loaded successfully!");
            // Return a custom object containing both the player and rooms
            return new LoadedGameData(loadedPlayer, loadedRooms);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            System.err.println("Error loading game: " + e.getMessage());
        }

        return null;
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to your adventure please select and option");
        System.out.println("Start the game? (Start)");
        System.out.println("Exit program? (Exit)");
        String input = scanner.nextLine();

        switch(input){
            case "Start":
                startGame();
                break;
            case"Exit":
                System.out.println("Please come back soon!");
                break;
            default:
                System.out.println("Invalid choice please select one of the options (Start/Exit) !case sensitive! ");
                break;
        }
        scanner.close();
    }

    public static void startGame(){
        TextBasedGame game = new TextBasedGame();
        Map<String,Monster> monsters = MonsterReader.readMonstersFromFile("monsters.txt");
        Map<String,Puzzle> puzzles = PuzzleReader.readPuzzlesFromFile("puzzles.txt");
        Map<String,Item> items = ItemReader.readItemsFromFile("items.txt");
        Map<String,Room> rooms = MapReader.loadMapFromFile("map.txt",items,puzzles,monsters);
        game.playGame(rooms);
    }
}
