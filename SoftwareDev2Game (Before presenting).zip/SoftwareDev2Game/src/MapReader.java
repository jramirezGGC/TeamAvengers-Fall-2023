import java.io.*;
import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.Collectors;

public class MapReader {
    private static Random random = new Random();
    public static Map<String, Room> loadMapFromFile(String filePath, Map<String, Item> items, Map<String, Puzzle> puzzles, Map<String, Monster> monsters) {
        Map<String, Room> rooms = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 7) { // increase if we add more parts will prob end up being 6 or 7 length
                    String roomName = parts[0].trim();
                    RoomType roomType = RoomType.valueOf(parts[1].trim());
                    String description = parts[2].trim();
                    String[] connections = parts[3].trim().split(",");
                    String roomItemsRaw = parts[4].trim();
                    String[] roomItemsSplit = roomItemsRaw.split(",");
                    String roomPuzzlesName = parts[5].trim();
                    String[] roomPuzzleSplit = roomPuzzlesName.split(",");
                    String roomMonsterName = parts[6].trim();
                    String[] roomMonsterSplit = roomMonsterName.split(",");
                    List<Item> roomItems = new ArrayList<>();
                    List<ItemType> desiredItemTypes = Arrays.asList(ItemType.WEAPON, ItemType.CONSUMABLE, ItemType.ARMOR);
                    List<Puzzle> roomPuzzle = new ArrayList<>();
                    List<Monster> roomMonster = new ArrayList<>();
                    String[] roomItemTypes = roomItemsRaw.split(",");
                    String[] roomItemNames = roomItemsRaw.split(",");


                        Set<ItemType> addedItemTypes = new HashSet<>();
                        for (String itemTypeString : roomItemTypes) {
                            try {
                                ItemType itemType = ItemType.valueOf(itemTypeString.trim());

                                // Check if the type has already been added
                                if (addedItemTypes.contains(itemType)) {
                                //    System.out.println(itemType + " already added to the room.");
                                    continue; // Skip if the type has already been added
                                }

                                // Filter items of the desired type
                                List<Item> itemsOfType = items.values().stream()
                                        .filter(item -> item.getItemType() == itemType)
                                        .collect(Collectors.toList());

                                if (!itemsOfType.isEmpty()) {
                                    // Select a random item of the desired type
                                    Item randomItem = itemsOfType.get(random.nextInt(itemsOfType.size()));
                                    roomItems.add(randomItem);
                                    addedItemTypes.add(itemType); // Mark the type as added
                                  //  System.out.println("Added random " + itemType + " item to the room: " + randomItem.getName());
                                } else {
                              //      System.out.println("No " + itemType + " items available.");
                                }
                            } catch (IllegalArgumentException e) {
                              //  System.out.println("Invalid item type: " + itemTypeString);
                            }
                        }
                    for (String itemName : roomItemNames) {
                        Item item = items.get(itemName.trim());
                        if (item != null) {
                            roomItems.add(item);
                          //  System.out.println("Added manual item to the room: " + item.getName());
                        } else {
                          //  System.out.println("Item not found: " + itemName.trim());
                        }
                    }
                    for (String itemTypeString : roomItemTypes) {
                        try {
                            ItemType itemType = ItemType.valueOf(itemTypeString.trim());

                            // Check if the type has already been added
                            if (addedItemTypes.contains(itemType)) {
                             //   System.out.println(itemType + " already added to the room.");
                                continue; // Skip if the type has already been added
                            }

                            // Filter items of the desired type
                            List<Item> itemsOfType = items.values().stream()
                                    .filter(item -> item.getItemType() == itemType)
                                    .collect(Collectors.toList());

                            if (!itemsOfType.isEmpty()) {
                                // Select a random item of the desired type
                                Item randomItem = itemsOfType.get(random.nextInt(itemsOfType.size()));
                                roomItems.add(randomItem);
                                addedItemTypes.add(itemType); // Mark the type as added
                              //  System.out.println("Added random " + itemType + " item to the room: " + randomItem.getName());
                            } else {
                              //  System.out.println("No " + itemType + " items available.");
                            }
                        } catch (IllegalArgumentException e) {
                            //System.out.println("Invalid item type: " + itemTypeString);
                        }
                    }

                    if (roomType == RoomType.NONSAFEROOM) {
                        // For NONSAFEROOM, add a random NORMAL monster
                        List<Monster> normalMonsters = monsters.values().stream()
                                .filter(monster -> monster.getMonsterType() == MonsterType.NORMAL)
                                .collect(Collectors.toList());

                        if (!normalMonsters.isEmpty()) {
                            Monster randomMonster = normalMonsters.get(random.nextInt(normalMonsters.size()));
                            roomMonster.add(randomMonster);
                            //System.out.println("Added NORMAL monster to NONSAFEROOM: " + randomMonster.getName());
                        } else {
                          //  System.out.println("No NORMAL monsters available for NONSAFEROOM.");
                        }
                    } else {
                        // For other room types, add the specified monsters from the file
                        for (String monsterName : roomMonsterSplit) {
                            Monster matchingMonster = monsters.get(monsterName);
                            if (matchingMonster != null) {
                                roomMonster.add(matchingMonster);
                            }
                        }
                    }

                        Room room = new Room(roomName, roomType, description, roomItems, roomPuzzle, roomMonster);
                        for (String connection : connections) {
                            String[] connParts = connection.trim().split("=");
                            if (connParts.length == 2) {
                                String direction = connParts[0].trim();
                                direction = direction.toLowerCase();
                                String connectedRoom = connParts[1].trim();
                                room.addConnection(direction, connectedRoom);
//                            System.out.println("con 0" + connParts[0]);
//                            System.out.println("Con 1" + connParts[1]);
                            }
                        }
                        rooms.put(roomName, room);
                    }
                }

        } catch (
                IOException e) {
            System.err.println("Error reading the map file: " + e.getMessage());
        }
        return rooms;
    }

}
